package com.addonslab.hyperos;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class XclusiveModsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        TextView title = new TextView(this);
        title.setText("Xclusive and Premium Mods");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        // Add exclusive mods
        addMod(layout, "Blur Enhancement", "Enhanced blur effects for UI", true);
        addMod(layout, "Advanced Gestures", "Custom gesture controls", false);
        addMod(layout, "Performance Mode", "Optimize system performance", true);
        addMod(layout, "Battery Saver Plus", "Extended battery optimization", false);
        
        setContentView(layout);
    }
    
    private void addMod(LinearLayout parent, String title, String description, boolean premium) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(24, 24, 24, 24);
        card.setBackgroundColor(0xFFF5F5F5);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 16);
        card.setLayoutParams(params);
        
        TextView titleView = new TextView(this);
        titleView.setText(title + (premium ? " 👑" : ""));
        titleView.setTextSize(18);
        titleView.setTextColor(0xFF000000);
        card.addView(titleView);
        
        TextView descView = new TextView(this);
        descView.setText(description);
        descView.setTextSize(14);
        descView.setTextColor(0xFF666666);
        descView.setPadding(0, 8, 0, 16);
        card.addView(descView);
        
        Button button = new Button(this);
        button.setText(premium ? "Unlock Premium" : "Activate");
        button.setOnClickListener(v -> {
            Toast.makeText(this, "Feature activated: " + title, Toast.LENGTH_SHORT).show();
        });
        card.addView(button);
        
        parent.addView(card);
    }
}
