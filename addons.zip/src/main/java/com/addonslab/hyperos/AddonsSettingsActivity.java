package com.addonslab.hyperos;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;

public class AddonsSettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        TextView title = new TextView(this);
        title.setText("Settings and Other Modifications");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        // Add your settings here
        addSetting(layout, "Enable Custom Animations", "Enable custom UI animations");
        addSetting(layout, "Dark Mode Enhancement", "Enhanced dark mode features");
        addSetting(layout, "Custom Fonts", "Use custom system fonts");
        
        setContentView(layout);
    }
    
    private void addSetting(LinearLayout parent, String title, String description) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setPadding(0, 16, 0, 16);
        
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        textLayout.setLayoutParams(textParams);
        
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(16);
        textLayout.addView(titleView);
        
        TextView descView = new TextView(this);
        descView.setText(description);
        descView.setTextSize(14);
        descView.setTextColor(0xFF999999);
        textLayout.addView(descView);
        
        Switch switchView = new Switch(this);
        
        item.addView(textLayout);
        item.addView(switchView);
        parent.addView(item);
    }
}