package com.addonslab.hyperos;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AddonsLabActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        
        // Add header
        View header = LayoutInflater.from(this).inflate(R.layout.addons_header, mainLayout, false);
        mainLayout.addView(header);
        
        // Add summary
        TextView summary = new TextView(this);
        summary.setText(R.string.addons_lab_summary);
        summary.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        summary.setPadding(32, 16, 32, 32);
        mainLayout.addView(summary);
        
        // Add menu items
        addMenuItem(mainLayout, "Settings", "Settings and Other Modifications", AddonsSettingsActivity.class);
        addMenuItem(mainLayout, "Xclusive Mods", "Xclusive and Premium Mods", XclusiveModsActivity.class);
        addMenuItem(mainLayout, "Spoofing", "Spoofing and Other Features", SpoofingActivity.class);
        addMenuItem(mainLayout, "Shortcuts", "Shortcut and Other Features", ShortcutsActivity.class);
        addMenuItem(mainLayout, "Credits", "Credits and Rom Info", CreditsActivity.class);
        
        setContentView(mainLayout);
    }
    
    private void addMenuItem(LinearLayout parent, String title, String summary, Class<?> targetActivity) {
        View item = LayoutInflater.from(this).inflate(R.layout.addons_menu_item, parent, false);
        
        TextView titleView = item.findViewById(R.id.menu_title);
        TextView summaryView = item.findViewById(R.id.menu_summary);
        
        titleView.setText(title);
        summaryView.setText(summary);
        
        item.setOnClickListener(v -> {
            Intent intent = new Intent(this, targetActivity);
            startActivity(intent);
        });
        
        parent.addView(item);
    }
}