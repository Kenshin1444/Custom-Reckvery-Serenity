package com.addonslab.hyperos;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.view.Gravity;

public class CreditsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        ScrollView scrollView = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        // Title
        TextView title = new TextView(this);
        title.setText("Credits and Rom Info");
        title.setTextSize(24);
        title.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        // ROM Info Section
        addSection(layout, "ROM Information");
        addInfo(layout, "ROM Name", "Speedox UI Turbo Edition");
        addInfo(layout, "Version", "OS2.206 YMOCNXM");
        addInfo(layout, "Based On", "HyperOS 2.0");
        addInfo(layout, "Android Version", "14");
        addInfo(layout, "Build Date", "January 2026");
        
        addSpace(layout, 32);
        
        // Developer Section
        addSection(layout, "Developer");
        addInfo(layout, "Developer", "Speedox Lab Team");
        addInfo(layout, "Website", "www.speedoxlab.com");
        addInfo(layout, "Telegram", "@speedoxlab");
        
        addSpace(layout, 32);
        
        // Credits Section
        addSection(layout, "Special Thanks");
        addCredit(layout, "LSPosed Team", "For the amazing Xposed framework");
        addCredit(layout, "Xiaomi", "For HyperOS base");
        addCredit(layout, "Community", "For continuous support");
        
        addSpace(layout, 32);
        
        // Footer
        TextView footer = new TextView(this);
        footer.setText("Made with ❤️ by Speedox Lab\n\n© 2026 All Rights Reserved");
        footer.setTextSize(14);
        footer.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);
        footer.setTextColor(0xFF999999);
        footer.setPadding(0, 32, 0, 0);
        layout.addView(footer);
        
        scrollView.addView(layout);
        setContentView(scrollView);
    }
    
    private void addSection(LinearLayout parent, String title) {
        TextView sectionTitle = new TextView(this);
        sectionTitle.setText(title);
        sectionTitle.setTextSize(20);
        sectionTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        sectionTitle.setPadding(0, 0, 0, 16);
        parent.addView(sectionTitle);
    }
    
    private void addInfo(LinearLayout parent, String label, String value) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setPadding(0, 8, 0, 8);
        
        TextView labelView = new TextView(this);
        labelView.setText(label + ":");
        labelView.setTextSize(16);
        labelView.setTextColor(0xFF666666);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        labelView.setLayoutParams(labelParams);
        
        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextSize(16);
        valueView.setTextColor(0xFF000000);
        valueView.setTextAlignment(TextView.TEXT_ALIGNMENT_VIEW_END);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        valueView.setLayoutParams(valueParams);
        
        item.addView(labelView);
        item.addView(valueView);
        parent.addView(item);
    }
    
    private void addCredit(LinearLayout parent, String name, String contribution) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(16, 12, 16, 12);
        item.setBackgroundColor(0xFFF5F5F5);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 8);
        item.setLayoutParams(params);
        
        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextSize(16);
        nameView.setTypeface(null, android.graphics.Typeface.BOLD);
        item.addView(nameView);
        
        TextView contribView = new TextView(this);
        contribView.setText(contribution);
        contribView.setTextSize(14);
        contribView.setTextColor(0xFF666666);
        contribView.setPadding(0, 4, 0, 0);
        item.addView(contribView);
        
        parent.addView(item);
    }
    
    private void addSpace(LinearLayout parent, int height) {
        TextView space = new TextView(this);
        space.setHeight(height);
        parent.addView(space);
    }
}