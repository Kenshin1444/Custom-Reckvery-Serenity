package com.addonslab.hyperos;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CheckBox;

public class ShortcutsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        TextView title = new TextView(this);
        title.setText("Shortcut and Other Features");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        addShortcut(layout, "Quick Settings Access", "Double tap status bar");
        addShortcut(layout, "Screenshot Shortcut", "Three finger swipe down");
        addShortcut(layout, "Screen Record", "Long press power + volume up");
        addShortcut(layout, "Flashlight", "Long press volume down (screen off)");
        addShortcut(layout, "Camera Quick Launch", "Double press power button");
        
        setContentView(layout);
    }
    
    private void addShortcut(LinearLayout parent, String name, String action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setPadding(0, 12, 0, 12);
        
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        textLayout.setLayoutParams(textParams);
        
        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextSize(16);
        textLayout.addView(nameView);
        
        TextView actionView = new TextView(this);
        actionView.setText(action);
        actionView.setTextSize(14);
        actionView.setTextColor(0xFF999999);
        textLayout.addView(actionView);
        
        CheckBox checkbox = new CheckBox(this);
        
        item.addView(textLayout);
        item.addView(checkbox);
        parent.addView(item);
    }
}