package com.addonslab.hyperos;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookMain implements IXposedHookLoadPackage {

    private static final String SETTINGS_PKG = "com.android.settings";
    private static final String TAG = "AddonsLab";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(SETTINGS_PKG)) return;

        XposedBridge.log(TAG + ": Hooking Settings app");

        try {
            // Hook Settings main fragment
            hookSettingsDashboard(lpparam);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Error - " + t.getMessage());
        }
    }

    private void hookSettingsDashboard(XC_LoadPackage.LoadPackageParam lpparam) {
        // Try different possible Settings fragment classes
        String[] possibleClasses = {
            "com.android.settings.Settings",
            "com.android.settings.SettingsActivity",
            "com.android.settings.homepage.SettingsHomepageActivity",
            "com.android.settings.MiuiSettings"
        };

        for (String className : possibleClasses) {
            try {
                Class<?> settingsClass = XposedHelpers.findClass(className, lpparam.classLoader);
                
                XposedHelpers.findAndHookMethod(settingsClass, "onCreate",
                    android.os.Bundle.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            injectAddonsMenu(param);
                        }
                    });
                
                XposedBridge.log(TAG + ": Successfully hooked " + className);
                break;
            } catch (Throwable t) {
                // Try next class
                continue;
            }
        }
    }

    private void injectAddonsMenu(XC_MethodHook.MethodHookParam param) {
        try {
            Context context = (Context) param.thisObject;
            
            // Wait for content view to be set
            View decorView = ((android.app.Activity) param.thisObject).getWindow().getDecorView();
            decorView.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        addAddonsLabCard(context, decorView);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + ": Error adding card - " + t.getMessage());
                    }
                }
            });

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Injection error - " + t.getMessage());
        }
    }

    private void addAddonsLabCard(Context context, View rootView) {
        // Find the main container
        ViewGroup container = findMainContainer(rootView);
        if (container == null) {
            XposedBridge.log(TAG + ": Main container not found");
            return;
        }

        // Create Add-ons Lab card
        LinearLayout addonsCard = createAddonsCard(context);
        
        // Insert at top
        container.addView(addonsCard, 0);
        
        XposedBridge.log(TAG + ": Add-ons Lab card added successfully");
    }

    private ViewGroup findMainContainer(View rootView) {
        // Try to find RecyclerView or main container
        if (rootView instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) rootView;
            
            // Search for suitable container
            for (int i = 0; i < vg.getChildCount(); i++) {
                View child = vg.getChildAt(i);
                String className = child.getClass().getSimpleName();
                
                if (className.contains("RecyclerView") || 
                    className.contains("ListView") ||
                    className.contains("ScrollView")) {
                    return (ViewGroup) child;
                }
                
                // Recursive search
                ViewGroup result = findMainContainer(child);
                if (result != null) return result;
            }
        }
        return null;
    }

    private LinearLayout createAddonsCard(Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(32, 32, 32, 32);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(32, 32, 32, 16);
        card.setLayoutParams(params);
        
        // Set gradient background
        int[] colors = {0xFF0066FF, 0xFF001F5C, 0xFF0066FF};
        android.graphics.drawable.GradientDrawable gradient = 
            new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                colors
            );
        gradient.setCornerRadius(32);
        card.setBackground(gradient);
        
        // Header
        TextView title = new TextView(context);
        title.setText("SPEEDOX UI");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        card.addView(title);
        
        // Edition
        TextView edition = new TextView(context);
        edition.setText("Turbo Edition");
        edition.setTextSize(16);
        edition.setTextColor(0xFFFFFFFF);
        edition.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams editionParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        editionParams.setMargins(0, 16, 0, 0);
        editionParams.gravity = android.view.Gravity.CENTER;
        edition.setLayoutParams(editionParams);
        card.addView(edition);
        
        // Build info
        TextView build = new TextView(context);
        build.setText("OS2.206 YMOCNXM");
        build.setTextSize(14);
        build.setTextColor(0xFFFFFFFF);
        build.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams buildParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        buildParams.setMargins(0, 8, 0, 0);
        buildParams.gravity = android.view.Gravity.CENTER;
        build.setLayoutParams(buildParams);
        card.addView(build);
        
        // Click listener
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AddonsLabActivity.class);
                context.startActivity(intent);
            }
        });
        
        return card;
    }
}