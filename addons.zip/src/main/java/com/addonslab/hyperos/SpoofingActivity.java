package com.addonslab.hyperos;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

public class SpoofingActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        TextView title = new TextView(this);
        title.setText("Spoofing and Other Features");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, 32);
        layout.addView(title);
        
        // Device Spoofing
        addSpinner(layout, "Device Model", new String[]{
            "Original Device",
            "Xiaomi 14 Pro",
            "Xiaomi 13 Ultra",
            "Redmi K60 Pro"
        });
        
        // Android Version Spoofing
        addSpinner(layout, "Android Version", new String[]{
            "Original Version",
            "Android 14",
            "Android 13",
            "Android 12"
        });
        
        // Build Prop Spoofing
        addSpinner(layout, "Build Type", new String[]{
            "Original",
            "Release",
            "Beta",
            "Alpha"
        });
        
        setContentView(layout);
    }
    
    private void addSpinner(LinearLayout parent, String label, String[] options) {
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(16);
        labelView.setPadding(0, 16, 0, 8);
        parent.addView(labelView);
        
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this,
            android.R.layout.simple_spinner_item,
            options
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setPadding(0, 0, 0, 16);
        parent.addView(spinner);
    }
}